import { useEffect, useRef, useState } from 'react'
import { supabase } from './supabase.js'
import { calc, rub, pct } from './calc.js'
import { norm, parseAmount, detectCategory, parseDate, detectIntent } from './assistant-logic.js'

const iso = d => new Date(d - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10)
const HELP = 'Я могу: записать расход («Добавь расход на доставку 500 сом»), показать убыточные и самые прибыльные товары, посчитать минимальную цену, расходы и рекламу за период, сравнить товары. Спросите своими словами.'

export default function Assistant({ items, expenses, reload, go }) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition
  const [open, setOpen] = useState(false); const [text, setText] = useState('')
  const [msgs, setMsgs] = useState([{ r: 'ai', t: 'Здравствуйте, я Санам, ваш финансовый помощник. ' + HELP }])
  const [speak, setSpeak] = useState(() => localStorage.getItem('speak') !== '0')
  const [pending, setPending] = useState(null); const [listening, setListening] = useState(false)
  const end = useRef(null)
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }) }, [msgs, open])
  useEffect(() => { localStorage.setItem('speak', speak ? '1' : '0') }, [speak])
  useEffect(() => { if ('speechSynthesis' in window) speechSynthesis.getVoices() }, [])

  function talk(t) {
    if (!speak || !('speechSynthesis' in window)) return
    speechSynthesis.cancel()
    const u = new SpeechSynthesisUtterance(t); u.lang = 'ru-RU'
    const vs = speechSynthesis.getVoices().filter(v => v.lang.toLowerCase().startsWith('ru'))
    const v = vs.find(v => /milena|alena|katya|irina|svetlana|google/i.test(v.name) && !/yuri|pavel|maxim|male/i.test(v.name)) || vs.find(v => !/yuri|pavel|maxim/i.test(v.name)) || vs[0]
    if (v) u.voice = v
    speechSynthesis.speak(u)
  }
  const say = t => { setMsgs(m => [...m, { r: 'ai', t }]); talk(t) }

  const all = items.map(p => ({ ...p, r: calc(p) }))
  const sum = (from, cat) => expenses.filter(e => e.date >= from && (!cat || e.category === cat)).reduce((s, e) => s + Number(e.amount) * Number(e.qty || 1), 0)
  const d30 = iso(new Date(Date.now() - 29 * 864e5)), month = iso(new Date()).slice(0, 8) + '01', today = iso(new Date())
  const line = p => `${p.name}: ${rub(p.r.profit)} с единицы, маржа ${pct(p.r.margin)}, продаж ${p.sales}`

  async function save() {
    const x = pending; setPending(null)
    const { error } = await supabase.from('expenses').insert({ category: x.category, amount: x.amount, qty: 1, date: x.date, product_id: x.pid || null, comment: 'Добавлено через Санам' })
    if (error) return say('Не получилось записать: ' + error.message)
    await reload()
    say(`Записала: ${x.category}, ${rub(x.amount)}. Расходы за 30 дней теперь ${rub(sum(d30) + x.amount)}.`)
  }

  async function handle(raw) {
    const t = norm(raw); if (!t) return
    setMsgs(m => [...m, { r: 'me', t: raw }]); setText('')
    const intent = detectIntent(t)
    if (pending && intent === 'yes') return save()
    if (pending && intent === 'no') { setPending(null); return say('Хорошо, не записываю.') }
    if (pending) setPending(null)
    const prod = items.find(p => t.includes(norm(p.name)) || (p.sku && t.includes(norm(p.sku))))
    if (intent === 'add_product') { go('calc'); return say('Открыла калькулятор: заполните карточку товара и нажмите «Сохранить товар».') }
    if (intent === 'add_expense') {
      const amount = parseAmount(t), category = detectCategory(t), date = parseDate(t)
      if (!(amount > 0)) return say('Не расслышала сумму. Повторите, например: «расход на доставку 500 сом».')
      const dup = expenses.some(e => e.category === category && Number(e.amount) === amount && e.date === date && (e.product_id || '') === (prod?.id || ''))
      setPending({ category, amount, date, pid: prod?.id })
      return say(`Записать расход: ${category}, ${rub(amount)}, дата ${date}, ${prod ? 'товар ' + prod.name : 'общий расход'}. ${dup ? 'Внимание: похожая запись уже есть. ' : ''}Подтверждаете? Скажите «да» или «нет».`)
    }
    if (intent === 'yes' || intent === 'no') return say('Сейчас нечего подтверждать.')
    if (!items.length && ['loss', 'top', 'minprice', 'compare', 'promote', 'profit'].includes(intent)) return say('В каталоге пока нет товаров. Добавьте товар, и я всё посчитаю.')
    switch (intent) {
      case 'profit': { const prof = all.reduce((s, p) => s + p.r.total, 0); const ex = sum(d30)
        return say(`Прибыль по товарам: ${rub(prof)}. Общие расходы за 30 дней: ${rub(ex)}. Чистая: ${rub(prof - ex)}. Продажи вводятся без дат, поэтому прибыль именно за сегодня посчитать не могу.`) }
      case 'loss': { const l = all.filter(p => p.r.profit < 0)
        return say(l.length ? 'Убыточные товары: ' + l.map(line).join('; ') + '.' : 'Убыточных товаров по введённым данным нет.') }
      case 'top': { const l = [...all].sort((a, b) => b.r.total - a.r.total).slice(0, 3)
        return say('Самые прибыльные по общей прибыли: ' + l.map(p => `${p.name}, всего ${rub(p.r.total)}, маржа ${pct(p.r.margin)}`).join('; ') + '.') }
      case 'minprice': { const l = prod ? [prod] : all.slice(0, 5)
        return say('Минимальная цена без убытка при текущих расходах: ' + l.map(p => { const r = p.r || calc(p); return `${p.name} ${rub(r.minPrice)} (сейчас ${rub(p.price)})` }).join('; ') + '.') }
      case 'compare': return say('Сравнение по марже: ' + [...all].sort((a, b) => b.r.margin - a.r.margin).map(p => `${p.name} ${pct(p.r.margin)}`).join('; ') + '.')
      case 'promote': { const l = all.filter(p => p.r.profit > 0).sort((a, b) => b.r.margin - a.r.margin)[0]
        return say(l ? `По введённым данным выгоднее продвигать ${l.name}: самая высокая маржа ${pct(l.r.margin)}, ${rub(l.r.profit)} с единицы. Это расчёт по вашим цифрам, а не прогноз спроса.` : 'Прибыльных товаров для продвижения пока нет.') }
      case 'ads': { const a = sum(month, 'Реклама'); const inProd = all.reduce((s, p) => s + p.r.ads * Number(p.sales || 0), 0)
        return say(`Расходы категории «Реклама» с начала месяца: ${rub(a)}. Отдельно, рекламная доля внутри товаров (ДРР × продажи): ${rub(inProd)}. Эти суммы я не складываю, чтобы не считать дважды.`) }
      case 'expenses': return say(`Расходы за сегодня: ${rub(sum(today))}. За 30 дней: ${rub(sum(d30))}. С начала месяца: ${rub(sum(month))}.`)
      case 'forecast': return say('Прогноз пока дать не могу: нужны продажи по датам, их в приложении ещё нет. Выдумывать цифры не буду.')
      case 'why': { const by = {}; expenses.filter(e => e.date >= d30).forEach(e => by[e.category] = (by[e.category] || 0) + Number(e.amount) * Number(e.qty || 1))
        const top = Object.entries(by).sort((a, b) => b[1] - a[1])[0]
        return say('Сравнить периоды не могу: у продаж нет дат. ' + (top ? `Могу сказать, что крупнейший расход за 30 дней: ${top[0]}, ${rub(top[1])}.` : '')) }
      default: return say(HELP)
    }
  }

  function listen() {
    if (!SR) return say('Ваш браузер не поддерживает голосовой ввод. Пишите текстом, я отвечу.')
    const r = new SR(); r.lang = 'ru-RU'; r.interimResults = false
    r.onstart = () => setListening(true); r.onend = () => setListening(false)
    r.onerror = e => say('Не удалось распознать речь (' + e.error + '). Проверьте доступ к микрофону или напишите текстом.')
    r.onresult = e => handle(e.results[0][0].transcript)
    r.start()
  }

  return <>
    <button className="sanam-fab" onClick={() => setOpen(!open)} aria-label="Санам"><img src="/sanam.jpg" alt="Санам" /></button>
    {open && <div className="sanam-panel card">
      <div className="sp-head"><img src="/sanam.jpg" alt="" /><b>Санам</b>
        <button className="btn ghost" onClick={() => setSpeak(!speak)}>{speak ? 'Голос: вкл' : 'Голос: выкл'}</button></div>
      <div className="sp-msgs">{msgs.map((m, i) => <div key={i} className={'bub ' + m.r}>{m.t}</div>)}<div ref={end} /></div>
      {pending && <div className="bar"><button className="btn gold" onClick={save}>Да, записать</button><button className="btn ghost" onClick={() => { setPending(null); say('Хорошо, не записываю.') }}>Нет</button></div>}
      <form className="bar" onSubmit={e => { e.preventDefault(); handle(text) }}>
        <input value={text} onChange={e => setText(e.target.value)} placeholder="Напишите или скажите…" />
        <button type="button" className={'btn ' + (listening ? 'gold' : 'ghost')} onClick={listen}>{listening ? 'Слушаю…' : 'Микрофон'}</button>
        <button className="btn gold">Отправить</button></form>
    </div>}
  </>
}
