export const norm = s => String(s).toLowerCase().replace(/ё/g, 'е').replace(/\s+/g, ' ').trim()
export function parseAmount(t) {
  const m = norm(t).match(/(\d+(?:[ \u00a0]\d{3})*(?:[.,]\d+)?)\s*(тыс\S*)?/)
  if (!m) return null
  let v = Number(m[1].replace(/[ \u00a0]/g, '').replace(',', '.'))
  if (m[2]) v *= 1000
  return Number.isFinite(v) ? v : null
}
const CATS = [[/международ/, 'Международная доставка'], [/доставк/, 'Доставка до склада'], [/закуп|товар/, 'Закупочная стоимость'],
  [/реклам/, 'Реклама'], [/упаков|маркиров/, 'Упаковка и маркировка'], [/таможн|налог/, 'Таможня и налоги'], [/хранен|склад/, 'Хранение'],
  [/комисси/, 'Комиссия маркетплейса'], [/эквайр/, 'Эквайринг'], [/возврат|брак|отмен/, 'Возвраты, отмены и брак'], [/зарплат|аренд/, 'Зарплата, аренда, операционные']]
export const detectCategory = t => (CATS.find(([re]) => re.test(norm(t))) || [0, 'Другое'])[1]
const iso = d => new Date(d - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10)
export const parseDate = t => iso(norm(t).includes('вчера') ? new Date(Date.now() - 864e5) : new Date())
export function detectIntent(raw) {
  const t = norm(raw)
  if (/^(да|подтверждаю|верно|записывай|давай|ок)(?=\s|$|[.,!])/.test(t)) return 'yes'
  if (/^(нет|отмена|отмени|не надо)(?=\s|$|[.,!])/.test(t)) return 'no'
  if (/(новый товар|добавь товар)/.test(t)) return 'add_product'
  if (/(добав|запиш|внеси)/.test(t) && parseAmount(t) != null) return 'add_expense'
  if (/прогноз/.test(t)) return 'forecast'
  if (/почему.*(упал|снизил|меньш)/.test(t)) return 'why'
  if (/(продвига|выгоднее)/.test(t)) return 'promote'
  if (/минимальн.*цен/.test(t)) return 'minprice'
  if (/реклам/.test(t)) return 'ads'
  if (/убыт/.test(t)) return 'loss'
  if (/(прибыльн|лучш)/.test(t)) return 'top'
  if (/сравн/.test(t)) return 'compare'
  if (/(заработал|прибыл)/.test(t)) return 'profit'
  if (/(расход|потрачен|потратил)/.test(t)) return 'expenses'
  return 'help'
}
