import { useEffect, useMemo, useState } from 'react'
import * as XLSX from 'xlsx'
import { supabase, configured } from './supabase.js'
import { FIELDS, EMPTY, calc, validate, rub, pct, setCurrency, CURRENCIES } from './calc.js'
import Expenses from './Expenses.jsx'
import Assistant from './Assistant.jsx'

const DEMO = { ...EMPTY, sku:'DEMO-1', name:'Демо-товар (можно удалить)', cost:300, price:900, length:20, width:15, height:10,
  weight:0.5, pack:15, delivery:20, commission:20, logistics:80, extra:10, drr:8, returns:5, sales:10 }
const NUM = FIELDS.filter(f => f[2] !== 'text').map(f => f[0])

function Auth() {
  const [email, setEmail] = useState(''); const [pass, setPass] = useState('')
  const [mode, setMode] = useState('in'); const [msg, setMsg] = useState('')
  async function go(e) {
    e.preventDefault(); setMsg('')
    const fn = mode === 'in' ? supabase.auth.signInWithPassword : supabase.auth.signUp
    const { error } = await fn.call(supabase.auth, { email, password: pass })
    if (error) setMsg(error.message); else if (mode === 'up') setMsg('Проверьте почту для подтверждения, затем войдите.')
  }
  return <div className="landing"><div className="hero"><img className="logo" src="/logo.png" alt="UNIT ECONOMY AI" />
    <p>Реальная прибыль каждого товара: данные, расходы и аналитика в одном месте.</p></div>
  <form className="auth card" onSubmit={go}>
    <h2>Вход</h2>
    <label>Email<input type="email" value={email} onChange={e => setEmail(e.target.value)} required /></label>
    <label>Пароль (от 6 символов)<input type="password" minLength={6} value={pass} onChange={e => setPass(e.target.value)} required /></label>
    {msg && <div className="err">{msg}</div>}
    <button className="btn gold">{mode === 'in' ? 'Войти' : 'Зарегистрироваться'}</button>
    <button type="button" className="btn ghost" onClick={() => setMode(mode === 'in' ? 'up' : 'in')}>
      {mode === 'in' ? 'Создать аккаунт' : 'У меня есть аккаунт'}</button>
  </form>
  <div className="feats">{[['ill-chart', 'Юнит-экономика', 'Прибыль, маржа и точка безубыточности по каждому товару.'],
    ['ill-costs', 'Учёт расходов', 'Все затраты по категориям, товарам и датам.'],
    ['ill-ai', 'AI-аналитика', 'Объяснения и рекомендации на ваших данных (этап 2).']].map(([i, t, d]) =>
    <div className="card" key={i}><img src={`/${i}.svg`} alt="" /><h3>{t}</h3><p className="note">{d}</p></div>)}</div>
  <div className="agent card"><img src="/sanam.jpg" alt="Санам" /><div><h3>Санам</h3>
    <p className="note">AI-помощница по финансам вашего товарного бизнеса. Войдите, и она ответит голосом и текстом.</p></div></div>
  </div>
}

function Results({ p, target, setTarget }) {
  const r = calc(p, target)
  const cls = r.profit < 0 ? 'neg' : 'pos'
  return <div className="grid" style={{ marginTop: 12 }}>
    {[['Объём', r.volume.toFixed(2) + ' л'], ['Полная себестоимость', rub(r.full)], ['Комиссия', rub(r.commission)],
      ['Реклама', rub(r.ads)], ['Потери от возвратов', rub(r.retLoss)]].map(([a, b]) => <div className="card" key={a}><small>{a}</small><strong>{b}</strong></div>)}
    <div className="card"><small>Прибыль с единицы</small><strong className={cls}>{rub(r.profit)}</strong></div>
    <div className="card"><small>Маржинальность</small><strong className={cls}>{pct(r.margin)}</strong></div>
    <div className="card"><small>Общая прибыль</small><strong className={cls}>{rub(r.total)}</strong></div>
    <div className="card"><small>Точка безубыточности (мин. цена)</small><strong>{rub(r.minPrice)}</strong></div>
    <div className="card"><small>Цена для целевой маржи</small><strong>{rub(r.target)}</strong>
      <label>Цель, %<input type="number" value={target} onChange={e => setTarget(Number(e.target.value))} /></label></div>
  </div>
}

export default function App() {
  const [session, setSession] = useState(null); const [ready, setReady] = useState(false)
  const [tab, setTab] = useState('dash'); const [items, setItems] = useState([])
  const [draft, setDraft] = useState(EMPTY); const [errs, setErrs] = useState([])
  const [q, setQ] = useState(''); const [sort, setSort] = useState({ k: 'name', d: 1 }); const [target, setTarget] = useState(15)
  const [busy, setBusy] = useState(false)
  const [cur, setCur] = useState(() => localStorage.getItem('cur') || 'KGS')
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'dark')
  const [expenses, setExpenses] = useState([]); const [period, setPeriod] = useState('30')
  setCurrency(cur)
  useEffect(() => { document.documentElement.dataset.theme = theme; localStorage.setItem('theme', theme) }, [theme])
  useEffect(() => { localStorage.setItem('cur', cur) }, [cur])

  useEffect(() => {
    if (!configured) { setReady(true); return }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true) })
    const { data: s } = supabase.auth.onAuthStateChange((_, ss) => setSession(ss))
    return () => s.subscription.unsubscribe()
  }, [])
  async function load() {
    const { data, error } = await supabase.from('products').select('*').order('created_at', { ascending: false })
    if (error) setErrs([error.message]); else setItems(data)
    const ex = await supabase.from('expenses').select('*').order('date', { ascending: false })
    if (ex.error) setErrs(['Расходы: ' + ex.error.message + ' (выполните supabase/schema_v2.sql)']); else setExpenses(ex.data)
  }
  useEffect(() => { if (session) load() }, [session])

  async function save() {
    const e = validate(draft); setErrs(e); if (e.length) return
    setBusy(true)
    const row = { ...draft }; NUM.forEach(k => row[k] = Number(String(row[k]).replace(',', '.')) || 0)
    delete row.created_at; row.updated_at = new Date().toISOString()
    const res = row.id ? await supabase.from('products').update(row).eq('id', row.id)
                       : await supabase.from('products').insert(row)
    setBusy(false)
    if (res.error) return setErrs([res.error.message])
    setDraft(EMPTY); await load(); setTab('cat')
  }
  async function del(id) {
    if (!confirm('Удалить товар?')) return
    const { error } = await supabase.from('products').delete().eq('id', id)
    if (error) setErrs([error.message]); else load()
  }
  async function importFile(ev) {
    const f = ev.target.files[0]; if (!f) return
    try {
      const wb = XLSX.read(await f.arrayBuffer()); const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]])
      const byLabel = Object.fromEntries(FIELDS.flatMap(([k, l]) => [[k, k], [l, k]]))
      const out = []; const bad = []
      rows.forEach((r, i) => {
        const o = { ...EMPTY }
        Object.entries(r).forEach(([h, v]) => { const k = byLabel[h.trim()]; if (k) o[k] = NUM.includes(k) ? Number(String(v).replace(',', '.')) || 0 : String(v) })
        const e = validate(o); if (e.length) bad.push(`Строка ${i + 2}: ${e[0]}`); else out.push(o)
      })
      if (out.length) { const { error } = await supabase.from('products').insert(out); if (error) bad.push(error.message) }
      setErrs(bad); load()
    } catch { setErrs(['Не удалось прочитать файл. Нужен .xlsx или .csv с заголовками как в таблице каталога.']) }
    ev.target.value = ''
  }
  function exportFile(type) {
    const data = items.map(p => Object.fromEntries(FIELDS.map(([k, l]) => [l, p[k]])))
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data), 'Товары')
    XLSX.writeFile(wb, `unit-economy.${type}`, { bookType: type })
  }

  const rows = useMemo(() => {
    const t = q.toLowerCase()
    const l = items.filter(p => (p.sku + ' ' + p.name).toLowerCase().includes(t)).map(p => ({ ...p, r: calc(p) }))
    const val = p => sort.k === 'profit' ? p.r.profit : sort.k === 'margin' ? p.r.margin : p[sort.k]
    return l.sort((a, b) => (val(a) > val(b) ? 1 : -1) * sort.d)
  }, [items, q, sort])

  if (!ready) return null
  if (!configured) return <main><div className="err">Не заданы VITE_SUPABASE_URL и VITE_SUPABASE_PUBLISHABLE_KEY. Добавьте их в переменные окружения Netlify и пересоберите сайт.</div></main>
  if (!session) return <Auth />

  const all = items.map(p => ({ ...p, r: calc(p) }))
  const rev = all.reduce((s, p) => s + p.r.revenue, 0), prof = all.reduce((s, p) => s + p.r.total, 0)
  const units = all.reduce((s, p) => s + Number(p.sales || 0), 0)
  const today = new Date(); const iso = d => d.toISOString().slice(0, 10)
  const from = period === 'all' ? '0000' : period === 'month' ? iso(today).slice(0, 8) + '01' : iso(new Date(Date.now() - (Number(period) - 1) * 864e5))
  const expTotal = expenses.filter(e => e.date >= from).reduce((s, e) => s + Number(e.amount || 0) * Number(e.qty || 1), 0)
  const th = (k, l) => <th onClick={() => setSort({ k, d: sort.k === k ? -sort.d : 1 })}>{l}{sort.k === k ? (sort.d > 0 ? ' ↑' : ' ↓') : ''}</th>

  return <>
    <header><span className="brand"><img src="/icon.png" alt="" />UNIT ECONOMY AI</span>
      <nav>{[['dash', 'Дашборд'], ['cat', 'Каталог'], ['exp', 'Расходы'], ['calc', 'Калькулятор']].map(([k, l]) =>
        <button key={k} className={tab === k ? 'on' : ''} onClick={() => { setTab(k); setErrs([]) }}>{l}</button>)}
        <select className="mini" value={cur} onChange={e => setCur(e.target.value)}>{CURRENCIES.map(c => <option key={c}>{c}</option>)}</select>
        <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? 'Светлая' : 'Тёмная'}</button>
        <button onClick={() => supabase.auth.signOut()}>Выйти</button></nav></header>
    <main>
      {errs.map((e, i) => <div className="err" key={i}>{e}</div>)}
      {tab === 'dash' && <>
        <div className="bar"><select value={period} onChange={e => setPeriod(e.target.value)}>
          <option value="1">Сегодня</option><option value="7">7 дней</option><option value="30">30 дней</option><option value="month">Текущий месяц</option><option value="all">Всё время</option></select></div>
        <div className="grid">
          <div className="card"><small>Выручка</small><strong>{rub(rev)}</strong></div>
          <div className="card"><small>Чистая прибыль</small><strong className={prof - expTotal < 0 ? 'neg' : 'pos'}>{rub(prof - expTotal)}</strong></div>
          <div className="card"><small>Средняя маржинальность</small><strong>{rev ? pct(prof / rev * 100) : '—'}</strong></div>
          <div className="card"><small>Продано, шт</small><strong>{units}</strong></div>
          <div className="card"><small>Общие расходы за период</small><strong>{rub(expTotal)}</strong></div>
          <div className="card"><small>Товаров с убытком</small><strong className="neg">{all.filter(p => p.r.profit < 0).length}</strong></div>
        </div>
        <h3>Лучшие товары по прибыли</h3>
        {all.length === 0 ? <p className="note">Каталог пуст. <button className="btn gold" onClick={async () => { await supabase.from('products').insert(DEMO); load() }}>Добавить демо-товар</button></p> :
          <div className="tw"><table><tbody>{[...all].sort((a, b) => b.r.total - a.r.total).slice(0, 5).map(p =>
            <tr key={p.id}><td>{p.name}</td><td className={p.r.total < 0 ? 'neg' : 'pos'}>{rub(p.r.total)}</td><td>{pct(p.r.margin)}</td></tr>)}</tbody></table></div>}
        <p className="note">Расчёты основаны только на введённых вами данных. Чистая прибыль = прибыль по товарам минус общие расходы за период (фильтр периода пока применяется только к расходам: у продаж нет дат). Динамика и AI-аналитика — этап 2.</p>
      </>}
      {tab === 'cat' && <>
        <div className="bar"><input placeholder="Поиск по SKU или названию" value={q} onChange={e => setQ(e.target.value)} />
          <button className="btn gold" onClick={() => { setDraft(EMPTY); setTab('calc') }}>Добавить</button>
          <label className="btn ghost" style={{ flexDirection: 'row', cursor: 'pointer' }}>Импорт<input hidden type="file" accept=".xlsx,.xls,.csv" onChange={importFile} /></label>
          <button className="btn ghost" onClick={() => exportFile('xlsx')}>Excel</button>
          <button className="btn ghost" onClick={() => exportFile('csv')}>CSV</button></div>
        <div className="tw"><table><thead><tr>{th('sku', 'SKU')}{th('name', 'Название')}{th('price', 'Цена')}{th('profit', 'Прибыль/шт')}{th('margin', 'Маржа')}{th('sales', 'Продаж')}<th></th></tr></thead>
          <tbody>{rows.map(p => <tr key={p.id}><td>{p.sku}</td><td>{p.name}</td><td>{rub(p.price)}</td>
            <td className={p.r.profit < 0 ? 'neg' : 'pos'}>{rub(p.r.profit)}</td><td>{pct(p.r.margin)}</td><td>{p.sales}</td>
            <td><button className="btn ghost" onClick={() => { setDraft(p); setTab('calc') }}>Изменить</button> <button className="btn ghost" onClick={() => del(p.id)}>Удалить</button></td></tr>)}</tbody></table></div>
      </>}
      {tab === 'exp' && <Expenses items={items} expenses={expenses} reload={load} setErrs={setErrs} />}
      {tab === 'calc' && <>
        <div className="form">{FIELDS.map(([k, l, t]) => <label key={k}>{l}
          <input type={t === 'text' ? 'text' : 'number'} step="any" min="0" value={draft[k] ?? ''} onChange={e => setDraft({ ...draft, [k]: e.target.value })} /></label>)}</div>
        <Results p={draft} target={target} setTarget={setTarget} />
        <p className="note">Допущение: потери от возвратов = % возвратов × (логистика + доп. расходы). Тарифы вводите вручную из кабинета маркетплейса. Валюта лишь меняет отображение: пересчёта курсов нет.</p>
        <button className="btn gold" disabled={busy} onClick={save}>{draft.id ? 'Сохранить изменения' : 'Сохранить товар'}</button>
      </>}
    </main>
    <Assistant items={items} expenses={expenses} reload={load} go={setTab} /></>
}
