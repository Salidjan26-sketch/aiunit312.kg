# UNIT ECONOMY AI — этап 1
Вход, каталог, калькулятор, дашборд, Supabase (RLS), импорт/экспорт Excel/CSV.

## Supabase (в браузере)
1. supabase.com → New project. В SQL Editor выполните по очереди `supabase/schema.sql`, затем `supabase/schema_v2.sql` (таблица расходов).
2. Settings → API Keys: скопируйте Project URL и Publishable key (не secret).
3. Authentication → URL Configuration: Site URL = адрес вашего сайта на Netlify.

## Публикация с iPhone
1. Загрузите папку проекта в репозиторий GitHub (github.com → New → Upload files).
2. app.netlify.com → Add new site → Import from Git → выберите репозиторий.
3. Build: `npm run build`, publish: `dist` (уже в netlify.toml).
4. Site configuration → Environment variables: добавьте VITE_SUPABASE_URL и VITE_SUPABASE_PUBLISHABLE_KEY.
5. Deploys → Trigger deploy. Откройте ссылку в Safari → «Поделиться» → «На экран Домой».

Импорт: первая строка файла — заголовки как в каталоге (SKU, Название, Закупка, ₽ …).
