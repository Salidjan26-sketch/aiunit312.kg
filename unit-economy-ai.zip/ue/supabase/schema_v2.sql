create table if not exists expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  product_id uuid references products(id) on delete set null,
  category text not null, amount numeric not null check (amount > 0), qty numeric not null default 1 check (qty > 0),
  date date not null default current_date, comment text default '', created_at timestamptz default now()
);
create index if not exists expenses_user_date on expenses(user_id, date desc);
alter table expenses enable row level security;
create policy "own expenses select" on expenses for select using (auth.uid() = user_id);
create policy "own expenses insert" on expenses for insert with check (auth.uid() = user_id);
create policy "own expenses update" on expenses for update using (auth.uid() = user_id);
create policy "own expenses delete" on expenses for delete using (auth.uid() = user_id);
